﻿namespace P01_HospitalDatabase.Data
{
    public class Configuration
    {
        public const string connection = @"Server=(localdb)\MSSQLLocalDB;DATABASE=Hospital;Integrated Security=True";
    }
}