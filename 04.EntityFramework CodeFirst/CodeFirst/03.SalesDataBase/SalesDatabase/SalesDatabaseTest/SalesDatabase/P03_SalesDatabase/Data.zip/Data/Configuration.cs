﻿namespace P03_SalesDatabase.Data
{

    public class Configuration
    {
        public const string ConnectionString = @"Server=.;Database=Sales;Integrated Security=True";
    }

}