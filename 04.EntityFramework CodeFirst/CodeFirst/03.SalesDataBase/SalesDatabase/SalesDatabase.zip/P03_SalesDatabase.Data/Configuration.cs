﻿namespace P03_SalesDatabase.Data
{
    public class Configuration
    {
        public const string connection = @"Server=(localdb)\MSSQLLocalDB;DATABASE=SalesDatabase;Integrated Security=True";
    }
}